# Nop.Plugin.Payments.LipanaMpesa
 A nopCommerce plugin for M-Pesa checkout payment option. To use it on your nopCommerce site, simply add it as a plugin project, clean and build
 ### Directly suported nopCommerce version 
 1. 4.30
 ### Want to use it in another nopCommerce store version?
 1. Update the DotNet to match the store version
 2. Update the Nuget packages
 3. Import the project as a plugin project on target version
 4. Clean and build to compile

### Want to use it in another site that is not nopCommerce powered?
The plugin is not directly compatible with all websites. Make sure to review the website compatibilty

### [Ready to deploy package](https://www.nopcommerce.com/en/lipanampesa)

##### [Need help to proceed?](https://habahabamall.com/contactus)

